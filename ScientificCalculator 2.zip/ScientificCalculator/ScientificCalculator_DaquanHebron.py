import math

while True:
    print("Choose a calculator")
    print("\t1. Basic Calculator")
    print("\t2. Scientific Calculator")
    selection = int(input("Select 1 or 2: "))
    if selection == 1:
        op = input(
            'What kind of operation would you like to do?\
            \nChoose between "+, -, *, /" : ')

        a = int(input('Please type the first number: '))
        b = int(input('Please type the second number: '))

        if op == '+':
           print(str(a) + ' ' + op + ' ' + str(b) + ' = ' + str(a + b))
        elif op == '-':
            print(str(a) + ' ' + op + ' ' + str(b) + ' = ' + str(a - b))
        elif op == '*':
            print(str(a) + ' ' + op + ' ' + str(b) + ' = ' + str(a * b))
        elif op == '/':
            if b == 0:
                print('Error: Cannot divide by 0')
            else:
                print(str(a) + ' ' + op + ' ' + str(b) + ' = ' + str(a / b))
        else:
            print("Incorrect operator! Please select one of the given options!")

    elif selection == 2:
        print("What kind of operation would you like to use?")
        op = input('Choose between "^, r, %, !, sin, cos, tan, ln" : ')

        if op == "^" or op == "r" or op == "%" or op == "!":
            a = float(input("Enter first number: "))
            b = float(input("Enter second number: "))
        elif op == "sin" or op == "tan" or op == "cos" or op == "ln":
            b = float(input("Enter first number: "))
        if op == "^":
            print(a, "^", b, "=", a ** b)
        elif op == "r":
            print(a, "root", b, "=", b ** (1 / a))
        elif op == "%":
            print(a, "%", b, "=", a % b)
        elif op == "!":
            num = a = b
            b = 1
            while a > 1:
                b *= a
                a = a - 1
            print("n!(", num, ")=", b)
        elif op == "sin":
            print("sin(", b, ")=", math.sin(b))
        elif op == "cos":
            print("cos(", b, ")=", math.cos(b))
        elif op == "tan":
            print("tan(", b, ")=", math.tan(b))
        elif op == "ln":
            print("ln(", b, ")= ", math.log(b))

    userResponse = input("Do you want to calculate again, then press 1 or press 2 to Exit: ")
    if userResponse == "2":
        print("Thanks for playing")
    if userResponse != "1":
        break
